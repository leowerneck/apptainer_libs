/*
 *  Definition of Lorene class Star_rot_diff
 *
 */

/*
 *   Copyright (c) 2025 Santiago Jaraba
 *
 *   This file is part of LORENE.
 *
 *   LORENE is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License version 2
 *   as published by the Free Software Foundation.
 *
 *   LORENE is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with LORENE; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef __STAR_ROT_DIFF_CFC_H_ 
#define __STAR_ROT_DIFF_CFC_H_ 

// Headers Lorene
#include "star_rot_cfc.h"

namespace Lorene {
/**
 * Class for differentially rotating stars in Conformal Flatness Condition  
 * and maximal slicing. \ingroup (star)
 *
 */

 class Star_rot_diff_CFC : public Star_rot_CFC {
    // Data : 
    // -----
    protected:
    /** Function \f$\Omega(F)\f$ defining the rotation profile.
	 *  The variable F is linked to the components of the fluid 4-velocity
	 *  by 
	 *  \f[
	 *	F = u^t u_\varphi \ . 
	 *  \f]
	 *  The first argument of \c omega_frot  must be \f$F\f$; the second
	 *  argument contains the parameters, the first of which being
	 *  necessarily the central value of \f$\Omega\f$.   
	 */
	double (*omega_frot)(double, const Tbl&) ;
	
	/** Primitive of the function \f$F\frac{d\Omega(F)}{dF}\f$, which vanishes at the
	 *  stellar center. 
	 *  The first argument of \c primfrot  must be \f$F\f$; the second
	 *  argument contains the parameters, the first of which being
	 *  necessarily the central value of \f$\Omega\f$.   
	 */
	double (*primfrot)(double, const Tbl&) ;
	
	/** Parameters of the function \f$\Omega(F)\f$.
	 * 
	 * To be used as the second argument of functions \c frot 
	 * and \c primfrot . 
	 * The parameter \c par_frot(0)  must always be the central angular
	 * velocity. 
	 */
	Tbl par_frot ; 
	
	/// Field \f$\Omega(r,\theta)\f$
	Scalar omega_field ; 
	
	double omega_min ;   ///< Minimum value of \f$\Omega\f$
	double omega_max ;   ///< Maximum value of \f$\Omega\f$
	
	/// Field \f$\int_0^F F'\,\frac{d\Omega(F')}{dF'} \, dF' \f$
	Scalar prim_field ; 
	
    // Constructors - Destructor
    // -------------------------
    public:
	/** Standard constructor. 
	 * 
	 * @param mp_i Mapping on which the star will be defined
	 * @param nzet_i Number of domains occupied by the star
	 * @param relat should be \c true  for a relativistic
	 *			star,  \c false  for a Newtonian one
	 * @param eos_i Equation of state of the stellar matter
	 * @param omega_frot_i Function \f$\Omega(F)\f$ defining the rotation profile.
	 * @param primfrot_i Primitive of \f$F\frac{d\Omega(F)}{dF}\f$ which vanishes at the
	 *   stellar center
	 * @param par_frot_i Parameters of functions \c omega_frot_i 
	 *     and \c primfrot_i , 
	 *	    \c par_frot_i(0)  being the central value of
	 *	    \f$\Omega\f$. 
	 */
	Star_rot_diff_CFC(Map& mp_i, int nzet_i, const Eos& eos_i, int relat_i, int filter,
		    double (*omega_frot_i)(double, const Tbl&), 
		    double (*primfrot_i)(double, const Tbl&), 
		    const Tbl& par_frot_i) ;			

	Star_rot_diff_CFC(const Star_rot_diff_CFC& ) ;		///< Copy constructor

	/** Constructor from a file (see \c sauve(FILE*) ). 
	 * 
	 * @param mp_i Mapping on which the star will be defined
	 * @param eos_i Equation of state of the stellar matter
	 * @param fich	input file (must have been created by the function
	 *	\c sauve )
	 * @param omega_frot_i Function \f$\Omega(F)\f$ defining the rotation profile.
	 * @param primfrot_i Primitive of \f$F\frac{d\Omega(F)}{dF}\f$ which vanishes at the
	 *   stellar center
	 */
	Star_rot_diff_CFC(Map& mp_i, const Eos& eos_i, FILE* fich,
			double (*omega_frot_i)(double, const Tbl&), 
			double (*primfrot_i)(double, const Tbl&) ) ;			

	virtual ~Star_rot_diff_CFC() ;			///< Destructor


	// Memory management
    // -----------------

    // Everything is inherited from Star_rot

    // Mutators / assignment
    // ---------------------
    public:
	/// Assignment to another \c Star_rot_diff 
	void operator=(const Star_rot_diff_CFC& ) ;	
	
    // Accessors
    // ---------
    public:
	/// Returns the angular velocity field \f$\Omega\f$
	const Scalar& get_omega_field() const {return omega_field;} ; 

	/** Returns the central value of the rotation angular velocity 
	 *  (\c [f_unit] )
	 */ 
    virtual double get_omega_c() const ;

    // Outputs
    // -------
    public:
	virtual void sauve(FILE *) const ;	    ///< Save in a file
    
	// Display in polytropic units
 	virtual void display_poly(ostream& ) const ;

	/// Display
	friend ostream& operator<<(ostream& , const Star& ) ;	


    protected:
	/// Operator >> (virtual function called by the operator <<). 
	virtual ostream& operator>>(ostream& ) const ;    

	/// Printing of some informations, excluding all global quantities
	virtual void partial_display(ostream& ) const ; 


    // Computational routines
    // ----------------------
	public: 

	virtual double tsw() const ;		///< Ratio T/W

	/** Computes the hydrodynamical quantities relative to the Eulerian
	 *  observer from those in the fluid frame.
	 *
	 *  The calculation is performed starting from the quantities
	 *  \c omega_field , \c ent , \c ener , \c press , 
	 *  and \c a_car ,  
	 *  which are supposed to be up to date.  
	 *  From these,  the following fields are updated:
	 *  \c gam_euler , \c u_euler , \c ener_euler , \c s_euler . 
	 * 
	 */
	virtual void hydro_euler() ; 

	/** Computes \f$\Omega(r,\theta)\f$ (member \c omega_field ).
	 *  
	 *  The computation amounts to solving the equation
	 *  \f[
	 *	\Omega - \Omega\left({B^2 r^2\sin^2\theta (\Omega - N^\varphi)
	 *	    \over N^2 - B^2 r^2 \sin^2(\Omega-N^\varphi)^2}\right) = 0
	 *  \f]
	 *  for \f$\Omega\f$. 
	 *
	 *  @param omeg_min [input] Lower bound of the interval for
	 *			     searching omega
	 *  @param omeg_max [input] Higher bound of the interval for
	 *			     searching omega
	 *  @param precis [input] Required precision in the determination of
	 *			the zero by the secant method
	 *  @param nitermax [input] Maximum number of iterations in the secant 
	 *			    method to compute the zero. 
	 */
	void fait_omega_field(double omeg_min, double omeg_max,
			      double precis, int nitermax) ;
	
	/// Computes the member \c prim_field  from \c omega_field .
	void fait_prim_field() ;
	
	/** Evaluates \f$\Omega(F)\f$, where \e F
	 *  is linked to the components of the fluid 4-velocity
	 *  by
	 *  \f[
	 *	F = u^t u_\varphi \ .
	 *  \f]
	 *
	 *  \c omega_funct  calls \c frot  with the parameters
	 *  \c par_frot .
	 *
	 *  @param F [input] value of \f$F\f$
	 *  @return value of \f$\Omega(F))\f$
	 *
	 */
	double omega_funct(double F) const ;  	

	/** Evaluates the primitive of \f$F\frac{d\Omega(F)}{dF}\f$.
	 * 
	 *  @param F [input] value of \f$F\f$
	 *  @return value of 
	 *	\f$\int_0^F F'\,\frac{d\Omega(F')}{dF'} \, dF' \f$
	 *
	 */
	double prim_funct_omega(double F) const ;  	

	/** Computes an equilibrium configuration.
	 *  
	 *  @param ent_c  [input] Central enthalpy 
	 *  @param omega0  [input] Requested central angular velocity 
	 *			     (if \c fact_omega=1. )
	 *  @param fact_omega [input] 1.01 = search for the Keplerian frequency,
	 *			      1. = otherwise.
	 *  @param nzadapt  [input] Number of (inner) domains where the mapping 
	 *			    adaptation to an iso-enthalpy surface
	 *			    should be performed
	 *  @param ent_limit [input] 1-D \c Tbl of dimension \c nzet  which
	 *				defines the enthalpy at the outer boundary
	 *				of each domain
	 *  @param icontrol [input] Set of integer parameters (stored as a
	 *			    1-D \c Itbl  of size 9) to control the 
	 *			    iteration: 
	 *	\li \c icontrol(0) = mer_max  : maximum number of steps 
	 *	\li \c icontrol(1) = mer_rot  : step at which the rotation is 
	 *				      switched on 
	 *	\li \c icontrol(2) = mer_change_omega  : step at which the rotation
	 *			  velocity is changed to reach the final one  
	 *	\li \c icontrol(3) = mer_fix_omega  :  step at which the final
	 *			    rotation velocity must have been reached  
	 *	\li \c icontrol(4) = mer_mass  : the absolute value of 
	 *			    \c mer_mass  is the step from which the 
	 *			    baryon mass is forced to converge, 
	 *			    by varying the central enthalpy 
	 *			    (\c mer_mass > 0 ) or the angular 
	 *			    velocity (\c mer_mass < 0 ) 
	 *	\li \c icontrol(5) = mermax_poisson  : maximum number of steps in 
	 *				\c Map_et::poisson  
	 *	\li \c icontrol(6) = mer_triax  : step at which the 3-D 
	 *				perturbation is switched on 
	 *	\li \c icontrol(7) = delta_mer_kep  : number of steps
	 *			    after \c mer_fix_omega  when \c omega 
	 *			    starts to be increased by \c fact_omega 
	 *			    to search for the Keplerian velocity
	 *	\li \c icontrol(8) = mer_diff  : step at which differential 
	 *				rotation is switched on
	 *
	 *  @param control [input] Set of parameters (stored as a 
	 *			    1-D \c Tbl  of size 7) to control the 
	 *			    iteration: 
	 *	\li \c control(0) = precis  : threshold on the enthalpy relative 
	 *				change for ending the computation 
	 *	\li \c control(1) = omega_ini  : initial central angular velocity, 
	 *			    switched on only if \c mer_rot < 0 , 
	 *			    otherwise 0 is used  
	 *	\li \c control(2) = relax  : relaxation factor in the main 
	 *				   iteration  
	 *	\li \c control(3) = relax_poisson  : relaxation factor in 
	 *				   \c Map_et::poisson  
	 *	\li \c control(4) = thres_adapt  :  threshold on dH/dr for 
	 *			    freezing the adaptation of the mapping 
	 *	\li \c control(5) = ampli_triax  :  relative amplitude of 
	 *			    the 3-D perturbation 
	 *	\li \c control(6) = precis_adapt  : precision for 
	 *			    \c Map_et::adapt 
	 *
	 *  @param mbar_wanted [input] Requested baryon mass (effective only 
	 *				if \c mer_mass > mer_max )
	 *  @param aexp_mass [input] Exponent for the increase factor of the 
	 *			      central enthalpy to converge to the 
	 *			      requested baryon mass
	 *  @param diff [output]   1-D \c Tbl  of size 7 for the storage of 
	 *			    some error indicators : 
	 *	    \li \c diff(0)  : Relative change in the enthalpy field
	 *			      between two successive steps 
	 *	    \li \c diff(1)  : Relative error in the resolution of the
	 *			    Poisson equation for \c nuf    
	 *	    \li \c diff(2)  : Relative error in the resolution of the
	 *			    Poisson equation for \c nuq    
	 *	    \li \c diff(3)  : Relative error in the resolution of the
	 *			    Poisson equation for \c dzeta    
	 *	    \li \c diff(4)  : Relative error in the resolution of the
	 *			    Poisson equation for \c tggg    
	 *	    \li \c diff(5)  : Relative error in the resolution of the
	 *			    equation for \c shift  (x comp.)   
	 *	    \li \c diff(6)  : Relative error in the resolution of the
	 *			    equation for \c shift  (y comp.)   
	 */
	virtual void equilibrium(double ent_c, double omega0, double fact_omega, 
			 int nzadapt, const Tbl& ent_limit,
			 const Itbl& icontrol, const Tbl& control,
			 double mbar_wanted, double aexp_mass, 
			 Tbl& diff, Param* = 0x0) ;
		 
 };

}
#endif