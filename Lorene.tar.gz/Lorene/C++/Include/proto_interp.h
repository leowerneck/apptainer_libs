/*
 *  Prototypes of non class-member functions for interpolation between mappings.
 *
 */

/*
 *   Copyright (c) 2024 Jerome Novak
 *
 *   This file is part of LORENE.
 *
 *   LORENE is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   LORENE is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with LORENE; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


#ifndef	__PROTO_INTERP_H_
#define	__PROTO_INTERP_H_

/*
 * $Id: proto_interp.h,v 1.1 2024/09/24 14:42:11 j_novak Exp $
 *
 * $Header: /cvsroot/Lorene/C++/Include/proto_interp.h,v 1.1 2024/09/24 14:42:11 j_novak Exp $
 *
 */

#include "tensor.h"

namespace Lorene {

  void cfrcheb_interp(const int*, const int*, double*, const int*, double*) ;
  void cfrchebp_interp(const int*, const int*, double*, const int*, double*) ;
  void cfrchebi_interp(const int*, const int*, double*, const int*, double*) ;

  void do_first_call_initializations
    (
     void (*coef_r0[MAX_BASE])(const int*, const int*, double*, const int*, double*),
     double (*som_r_1d0[MAX_BASE])(const double*, int, double)
     ) ;
  bool check_grids(const Map_af&, const Map_star&, int&) ;
  bool check_grids(const Map_star&, const Map_af&, int&) ;
  void pasprevu_r(const int*, const int*, double*, const int*, double*) ;
  void base_non_def_r(const int*, const int*, double*, const int*, double*) ;

}

#endif

